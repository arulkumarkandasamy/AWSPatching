import boto3
import os
import time
import json
import dateutil.parser
from datetime import datetime, timezone

ses = boto3.client('ses')
ssm = boto3.client('ssm')
ec2 = boto3.client('ec2')
dynamodb = boto3.resource('dynamodb')

API_URL       = os.environ['API_URL']
HISTORY_TABLE = os.environ['HISTORY_TABLE']
OWNER_MAP     = json.loads(os.environ['OWNER_MAP'])
PATCH_TAG     = os.environ['PATCH_TAG_VALUE']
SENDER_EMAIL  = os.environ['SENDER_EMAIL']

hist_table = dynamodb.Table(HISTORY_TABLE)

def lambda_handler(event, context):
    print("Starting Maintenance Window Poll...")
    paginator = ssm.get_paginator('describe_maintenance_windows')
    for page in paginator.paginate():
        for window in page['WindowIdentities']:
            check_window(window)

def check_window(window):
    window_id = window['WindowId']
    name = window['Name']
    
    # Filter for our specific windows (CCS-Dev or CCS-Prod)
    if "CCS" not in name: return

    try:
        details = ssm.get_maintenance_window(WindowId=window_id)
        next_exec_str = details['NextExecutionTime']
        next_exec_dt = dateutil.parser.parse(next_exec_str)
        now_dt = datetime.now(timezone.utc)
        diff = next_exec_dt - now_dt
        hours_remaining = diff.total_seconds() / 3600
        
        # Check alerts: 7 Days (approx) or 1 Day (approx)
        alert_type = None
        if 166 <= hours_remaining <= 169:
            alert_type = "7Day"
        elif 23 <= hours_remaining <= 25:
            alert_type = "1Day"
            
        if alert_type:
            send_targeted_notifications(window_id, name, next_exec_str, alert_type)
            
    except Exception as e:
        print(f"Error checking window {window_id}: {e}")

def get_target_instances():
    # Find all instances that belong to this Patch Group
    instances = []
    paginator = ec2.get_paginator('describe_instances')
    iterator = paginator.paginate(
        Filters=[{'Name': 'tag:PatchGroup', 'Values': [PATCH_TAG]}]
    )
    for page in iterator:
        for r in page['Reservations']:
            for i in r['Instances']:
                instances.append(i['InstanceId'])
    return instances

def send_targeted_notifications(window_id, window_name, execution_time, alert_type):
    # 1. Check Deduplication
    alert_key = f"{execution_time}#{alert_type}"
    try:
        resp = hist_table.get_item(Key={'WindowId': window_id, 'AlertKey': alert_key})
        if 'Item' in resp:
            print(f"Skipping {alert_type} - Already processed.")
            return
    except Exception as e:
        print(f"DB Error: {e}")

    # 2. Get Targets
    target_ids = get_target_instances()
    print(f"Found {len(target_ids)} instances in patch group {PATCH_TAG}")

    # 3. Iterate and Email Owners
    readable_type = alert_type.replace("Day", " Day")
    
    for instance_id in target_ids:
        owner_email = OWNER_MAP.get(instance_id)
        
        if owner_email:
            account_id = boto3.client('sts').get_caller_identity().get('Account')
            opt_out_link = f"{API_URL}/opt-out?accountId={account_id}"
            
            subject = f"ACTION REQUIRED: Patching for {instance_id} in {readable_type}"
            body = f"""
            Hello,
            
            Your instance {instance_id} is scheduled for patching.
            
            Window: {window_name}
            Time: {execution_time}
            
            If you need to defer this patch cycle, please click the link below:
            {opt_out_link}
            """
            
            try:
                ses.send_email(
                    Source=SENDER_EMAIL,
                    Destination={'ToAddresses': [owner_email]},
                    Message={
                        'Subject': {'Data': subject},
                        'Body': {'Text': {'Data': body}}
                    }
                )
                print(f"Sent email to {owner_email} for {instance_id}")
            except Exception as e:
                print(f"Failed to email {owner_email}: {e}")

    # 4. Update History
    ttl = int(time.time()) + (30 * 24 * 60 * 60)
    hist_table.put_item(
        Item={
            'WindowId': window_id,
            'AlertKey': alert_key,
            'SentAt': str(datetime.now()),
            'Expiry': ttl
        }
    )
