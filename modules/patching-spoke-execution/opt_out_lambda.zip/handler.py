import boto3
import os
import time

dynamodb = boto3.resource('dynamodb')
table_name = os.environ['TABLE_NAME']
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    try:
        query_params = event.get('queryStringParameters') or {}
        account_id = query_params.get('accountId')
        if not account_id:
            return {"statusCode": 400, "body": "Missing AccountId"}

        # Set Opt-Out to expire in 7 days
        expiry = int(time.time()) + (7 * 24 * 60 * 60)
        
        table.put_item(
            Item={
                'AccountId': account_id,
                'OptOutExpiry': expiry,
                'Status': 'Opted-Out'
            }
        )
        
        html = """
        <html>
        <body style="font-family: sans-serif; text-align: center; padding: 50px;">
            <h1 style="color: green;">Opt-Out Successful</h1>
            <p>Patching for Account <b>{}</b> has been postponed to the next cycle.</p>
        </body>
        </html>
        """.format(account_id)

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "text/html"},
            "body": html
        }
    except Exception as e:
        print(e)
        return {"statusCode": 500, "body": "Error processing request"}
